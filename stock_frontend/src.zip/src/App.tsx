// App.tsx
import React from 'react';
import Login from './components/Login';
import Register from './components/Register';
import Watchlist from './components/Watchlist';
import ResponsiveAppBar from './components/NavBar';
import { Route, Routes } from 'react-router-dom';


const App: React.FC = () => {
  return (
    <div>
      <ResponsiveAppBar/>
      <Routes>
        <Route path='/login' element={<Login/>} />
        <Route path='/register' element={<Register/>} />
        <Route path='/watchlist' element={<Watchlist/>} />
      </Routes>
      {/* <h1>Stock Monitoring Platform</h1>
      <Login />
      <Register />
      <Watchlist /> */}
    </div>
  );
};

export default App;
