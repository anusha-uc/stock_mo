// Watchlist.tsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';

interface WatchlistItem {
  symbol: string;
}

const Watchlist: React.FC = () => {
  const [watchlist, setWatchlist] = useState<WatchlistItem[]>([]);

  useEffect(() => {
    fetchWatchlist();
  }, []);

  const fetchWatchlist = async () => {
    try {
      const response = await axios.get('/watchlist');
      setWatchlist(response.data);
    } catch (error) {
      console.error('Fetch watchlist error:', error);
      // Handle fetch watchlist error
    }
  };

  return (
    <div>
      <h2>Watchlist</h2>
      <ul>
        {watchlist.map((item, index) => (
          <li key={index}>{item.symbol}</li>
        ))}
      </ul>
    </div>
  );
};

export default Watchlist;
